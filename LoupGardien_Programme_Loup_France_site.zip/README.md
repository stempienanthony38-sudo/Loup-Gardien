# LoupGardien — Programme Loup France

Site statique prêt pour GitHub Pages.

## Identité
- Nom public : **LoupGardien**
- Projet : **Programme Loup France**
- Fondateur : **Anthony · LoupGardien**

## Mise en ligne
Le dépôt GitHub d'un site personnel doit être nommé `TONPSEUDO.github.io`.
Place le contenu de ce dossier à la racine du dépôt puis active GitHub Pages depuis Settings > Pages.

Le site est volontairement formulé comme un projet en phase de structuration : aucune promesse de capture, d'acquisition, de reproduction, de transport ou de libération d'animaux n'est faite en dehors des cadres scientifiques et réglementaires applicables.

## À compléter avant publication officielle
- identité juridique de la structure ;
- adresse e-mail professionnelle réelle ;
- mentions légales complètes ;
- politique de confidentialité adaptée aux outils réellement utilisés ;
- partenaires scientifiques et vétérinaires confirmés ;
- informations de financement vérifiables.
